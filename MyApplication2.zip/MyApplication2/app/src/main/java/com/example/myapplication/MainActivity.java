package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etEmail;
    private EditText etIdade;
    private EditText etDisciplina;
    private EditText etNotaPriBim;
    private EditText etNotaSegBim;
    private TextView tvResultado;
    private Button btmostrarResultado;
    private Button btLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNotaPriBim = findViewById(R.id.etNotaPriBim);
        etNotaSegBim = findViewById(R.id.etNotaSegBim);
        btmostrarResultado = findViewById(R.id.btLimpar);
        btLimpar = findViewById(R.id.btLimpar);
        tvResultado = findViewById(R.id.tvResultado);

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvResultado.setText("");
            }
        });

        btmostrarResultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularResultado();
            }
        });
    }

    private void calcularResultado() {
        String nome = etNome.getText().toString();
        String disciplina = etDisciplina.getText().toString();
        String email = etEmail.getText().toString();
        String primBim = etNotaPriBim.getText().toString();
        String segBim = etNotaSegBim.getText().toString();
        int idade = Integer.parseInt(etIdade.getText().toString());
        double segundaNota = Double.parseDouble(segBim);
        double primeiraNota = Double.parseDouble(primBim);



        if (!isValidEmail(email)) {
            etEmail.setError("E-mail inválido.");
            return;
        }

        try {
            if (idade < 0) {
                etIdade.setError("Idade inválida.");
                return;
            }
        } catch (NumberFormatException e) {
            etIdade.setError("Informe um número inteiro para a idade.");
            return;
        }


        if (nome.isEmpty()) {
            etNome.setError("Informe seu nome.");
            return;
        }

        if (disciplina.equals("")) {
            etDisciplina.setText("Disciplina Inválida");
        } else {
            etDisciplina.setText(disciplina);
        }

        try {


            if (primeiraNota >= 0 && primeiraNota <= 10) {
                Toast.makeText(this, "Nota válida!", Toast.LENGTH_SHORT).show();
            } else {
                etNotaPriBim.setText("Nota Inválida: A nota deve estar entre 0 e 10.");
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Digite um número válido.", Toast.LENGTH_SHORT).show();
        }

        try {

            if (segundaNota > 0 && segundaNota < 10) {
                Toast.makeText(this, "Nota válida!", Toast.LENGTH_SHORT).show();
            } else {
                etNotaSegBim.setText("Nota Inválida: A nota deve estar entre 0 e 10.");
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Digite um número válido.", Toast.LENGTH_SHORT).show();
        }

        double media = (primeiraNota + segundaNota) / 2;
        String mensagem;
        if (media >= 7) {
            mensagem = "Aprovado";
        } else {
            mensagem = "Reprovado";
        }

        tvResultado.setText("Nome: " + nome + "\n" + "E-mail: " + email + "\n" +
                "Idade: " + idade + "\n" + "Disciplina: " + disciplina + "\n" +
                "Nota 1º Bimestre: " + primeiraNota + "\n" + "Nota 2º Bimestre: " + segundaNota + "\n" + "Média: " + media + "\n" +
                mensagem);
    }

    private boolean isValidEmail(String email) {
        return email.contains("@") && email.indexOf("@") > 0;
    }
}